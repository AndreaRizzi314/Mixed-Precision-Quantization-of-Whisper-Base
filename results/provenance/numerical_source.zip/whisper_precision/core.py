"""Dependency-light scoring and allocation logic."""
from __future__ import annotations

import random
import re
import unicodedata

GROUPS = (
    "audio_convolutions", "encoder_attention", "encoder_feed_forward",
    "decoder_self_attention", "decoder_cross_attention",
    "decoder_feed_forward", "embeddings",
)


def normalize(text: str) -> str:
    """Uppercase, strip punctuation without splitting contractions, collapse whitespace."""
    text = unicodedata.normalize("NFKC", text).upper()
    return " ".join("".join(c for c in text if c.isalnum() or c.isspace()).split())


def word_errors(reference: str, hypothesis: str) -> tuple[int, int]:
    """Return Levenshtein word edits and reference word count."""
    a, b = normalize(reference).split(), normalize(hypothesis).split()
    row = list(range(len(b) + 1))
    for i, word in enumerate(a, 1):
        new = [i]
        for j, predicted in enumerate(b, 1):
            new.append(min(row[j] + 1, new[-1] + 1, row[j - 1] + (word != predicted)))
        row = new
    return row[-1], len(a)


def corpus_wer(pairs: list[tuple[str, str]]) -> dict:
    counts = [word_errors(ref, hyp) for ref, hyp in pairs]
    edits = sum(x for x, _ in counts)
    words = sum(n for _, n in counts)
    if not words:
        raise ValueError("References contain no words")
    return {"wer": edits / words, "errors": edits, "reference_words": words,
            "clip_wer": [x / n if n else None for x, n in counts]}


def group_for_parameter(name: str) -> str | None:
    if not (name.endswith(".weight") or name.endswith("embed_positions")):
        return None
    if name.startswith("model.encoder.conv") and name.endswith(".weight"):
        return "audio_convolutions"
    if name.startswith("model.encoder.layers."):
        if ".self_attn." in name:
            return "encoder_attention"
        if re.search(r"\.fc[12]\.weight$", name):
            return "encoder_feed_forward"
    if name.startswith("model.decoder.layers."):
        if ".self_attn." in name:
            return "decoder_self_attention"
        if ".encoder_attn." in name:
            return "decoder_cross_attention"
        if re.search(r"\.fc[12]\.weight$", name):
            return "decoder_feed_forward"
    if "embed_tokens.weight" in name or "embed_positions.weight" in name or name.endswith("embed_positions"):
        return "embeddings"
    return None


def cost_bits(group_sizes: dict[str, int], fixed_numel: int, preserved: set[str]) -> int:
    return 32 * fixed_numel + sum(size * (32 if group in preserved else 8)
                                   for group, size in group_sizes.items())


def allocate(group_sizes: dict[str, int], fixed_numel: int, benefit: dict[str, float],
             budget_bits: int, method: str, seed: int) -> list[str]:
    """Choose FP32 groups over a simulated INT8 floor, keeping within budget."""
    selected: list[str] = []
    remaining = list(group_sizes)
    if cost_bits(group_sizes, fixed_numel, set()) > budget_bits:
        raise ValueError("Budget is below simulated INT8 floor")
    if method == "greedy":
        remaining.sort(key=lambda g: (-max(benefit.get(g, 0), 0) / (24 * group_sizes[g]), g))
    elif method == "largest":
        remaining.sort(key=lambda g: (-group_sizes[g], g))
    elif method == "random":
        random.Random(seed).shuffle(remaining)
    else:
        raise ValueError(f"Unknown allocation method: {method}")
    for group in remaining:
        if method == "greedy" and benefit.get(group, 0) <= 0:
            continue
        if cost_bits(group_sizes, fixed_numel, set(selected) | {group}) <= budget_bits:
            selected.append(group)
    return selected


def fake_int8(tensor):
    """Per-output-row symmetric weight quantization, immediately dequantized to FP32."""
    import torch
    values = tensor.detach().float()
    rows = values.reshape(values.shape[0], -1)
    scale = rows.abs().amax(dim=1, keepdim=True).clamp_min(1e-12) / 127
    q = torch.round(rows / scale).clamp(-127, 127)
    return (q * scale).reshape_as(values).to(tensor.dtype)
