"""Inference and model variants. Simulated quantization retains FP32 tensors."""
from __future__ import annotations

import importlib.metadata
import json
import os
import platform
import subprocess
import statistics
import time
from pathlib import Path

from .core import GROUPS, corpus_wer, fake_int8, group_for_parameter


def environment(config: dict) -> dict:
    import torch
    from huggingface_hub import HfApi
    packages = ("torch", "transformers", "datasets", "soundfile", "huggingface-hub",
                "numpy", "openvino", "nncf", "optimum-intel", "matplotlib")
    versions = {}
    for package in packages:
        try:
            versions[package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            versions[package] = None
    model_revision = HfApi().model_info(config["model_id"]).sha
    try:
        nvidia = subprocess.run(["nvidia-smi", "--query-gpu=name,memory.total,driver_version",
                                 "--format=csv,noheader"], capture_output=True, text=True,
                                timeout=10, check=True).stdout.strip()
    except (OSError, subprocess.SubprocessError):
        nvidia = None
    try:
        import openvino as ov
        openvino_devices = ov.Core().available_devices
    except Exception:
        openvino_devices = []
    return {"model_id": config["model_id"], "model_revision": model_revision,
            "python": platform.python_version(), "os": platform.platform(),
            "cpu": platform.processor(), "logical_cpu_count": os.cpu_count(),
            "cuda_available": torch.cuda.is_available(),
            "cuda_gpu": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
            "nvidia_smi": nvidia, "openvino_devices": openvino_devices,
            "packages": versions, "seed": config["seed"]}


def device_for(config: dict) -> str:
    import torch
    selected = config["device"]
    if selected == "auto":
        return "cuda" if torch.cuda.is_available() else "cpu"
    if selected == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but unavailable")
    return selected


def load_torch(config: dict, root: Path):
    import torch
    from transformers import AutoProcessor, WhisperForConditionalGeneration
    env = json.loads((root / "environment.json").read_text(encoding="utf-8"))
    model_id, revision = config["model_id"], env["model_revision"]
    processor = AutoProcessor.from_pretrained(model_id, revision=revision)
    model = WhisperForConditionalGeneration.from_pretrained(model_id, revision=revision,
                                                            dtype=torch.float32)
    model.eval().to(device_for(config))
    return model, processor


def parameter_inventory(model) -> dict:
    inventory = {group: [] for group in GROUPS}
    fixed = []
    for name, param in model.named_parameters():
        group = group_for_parameter(name) if param.ndim >= 2 else None
        entry = {"name": name, "shape": list(param.shape), "numel": param.numel()}
        (inventory[group] if group else fixed).append(entry)
    if any(not inventory[group] for group in GROUPS):
        raise RuntimeError("Expected Whisper Base groups are empty; inspect model parameter names")
    return {"groups": inventory, "fixed_fp32": fixed,
            "group_numel": {g: sum(p["numel"] for p in ps) for g, ps in inventory.items()},
            "fixed_numel": sum(p["numel"] for p in fixed)}


def _audio_features(processor, clip: dict):
    import soundfile as sf
    samples, rate = sf.read(clip["audio"], dtype="float32")
    return processor(samples, sampling_rate=rate, return_tensors="pt", return_attention_mask=True)


def evaluate(model, processor, clips: list[dict], config: dict, backend: str,
             features_for_clip=None) -> dict:
    import torch
    predictions = []
    timings = []
    device = device_for(config) if backend == "torch" else "cpu"
    for clip in clips:
        inputs = features_for_clip(clip) if features_for_clip is not None else _audio_features(processor, clip)
        if backend == "torch":
            inputs = inputs.to(device)
        clip_times = []
        decoded = None
        for _ in range(config["timing_repeats"]):
            if backend == "torch" and device == "cuda":
                torch.cuda.synchronize()
            start = time.perf_counter()
            with torch.inference_mode():
                tokens = model.generate(**inputs, language="en", task="transcribe",
                                        temperature=0.0, do_sample=False, num_beams=1,
                                        max_new_tokens=config["max_new_tokens"],
                                        condition_on_prev_tokens=False)
            if backend == "torch" and device == "cuda":
                torch.cuda.synchronize()
            clip_times.append(time.perf_counter() - start)
            text = processor.batch_decode(tokens, skip_special_tokens=True)[0]
            if decoded is not None and decoded != text:
                raise RuntimeError("Non-deterministic decoding across timing repeats")
            decoded = text
        predictions.append({"id": clip["id"], "reference": clip["text"],
                            "hypothesis": decoded, "seconds": clip["seconds"],
                            "latency_s": clip_times})
        timings.extend(clip_times)
    score = corpus_wer([(x["reference"], x["hypothesis"]) for x in predictions])
    return {"wer": score["wer"], "errors": score["errors"],
            "reference_words": score["reference_words"], "clip_wer": score["clip_wer"],
            "latency_median_s": statistics.median(timings), "latency_repeats_s": timings,
            "predictions": predictions, "backend": backend}


def apply_simulated_int8(model, inventory: dict, preserved: set[str], originals: dict):
    """Replace weights in place; originals must be restored after each condition."""
    named = dict(model.named_parameters())
    with __import__("torch").no_grad():
        for group, entries in inventory["groups"].items():
            for entry in entries:
                name = entry["name"]
                source = originals[name]
                named[name].copy_(source if group in preserved else fake_int8(source))


def restore(model, originals: dict):
    with __import__("torch").no_grad():
        named = dict(model.named_parameters())
        for name, source in originals.items():
            named[name].copy_(source)


def evaluate_torch_conditions(config: dict, root: Path, conditions: list[tuple[str, set[str]]],
                              split_kind: str, inventory: dict | None = None) -> dict:
    from .data import read_manifest
    model, processor = load_torch(config, root)
    inventory = inventory or parameter_inventory(model)
    original = {entry["name"]: dict(model.named_parameters())[entry["name"]].detach().clone()
                for entries in inventory["groups"].values() for entry in entries}
    clips = read_manifest(root, split_kind)["clips"]
    results = {}
    try:
        for label, preserved in conditions:
            print(f"Evaluating {split_kind}: {label}", flush=True)
            if preserved == set(GROUPS):
                restore(model, original)
            else:
                apply_simulated_int8(model, inventory, preserved, original)
            results[label] = evaluate(model, processor, clips, config, "torch")
            results[label]["preserved_groups"] = sorted(preserved)
    finally:
        restore(model, original)
    return {"inventory": inventory, "conditions": results}


def evaluate_openvino(config: dict, root: Path, split_kind: str, quantized: bool) -> dict:
    from optimum.intel.openvino import OVModelForSpeechSeq2Seq, OVWeightQuantizationConfig
    from transformers import AutoProcessor
    from .data import read_manifest
    env = json.loads((root / "environment.json").read_text(encoding="utf-8"))
    model_id, revision = config["model_id"], env["model_revision"]
    options = {"revision": revision, "export": True, "compile": False}
    if quantized:
        options["quantization_config"] = OVWeightQuantizationConfig(bits=8)
    model = OVModelForSpeechSeq2Seq.from_pretrained(model_id, **options)
    target = root / "models" / ("ov_int8" if quantized else "ov_fp32")
    target.mkdir(parents=True, exist_ok=True)
    model.save_pretrained(target)
    model.compile()
    processor = AutoProcessor.from_pretrained(model_id, revision=revision)
    result = evaluate(model, processor, read_manifest(root, split_kind)["clips"], config, "openvino")
    result["serialized_bytes"] = sum(p.stat().st_size for p in target.rglob("*") if p.is_file())
    result["serialized_path"] = str(target)
    result["quantized"] = quantized
    return result
