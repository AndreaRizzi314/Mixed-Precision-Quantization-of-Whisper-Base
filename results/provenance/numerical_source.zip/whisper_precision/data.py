"""Download only small, pinned LibriSpeech clean subsets."""
from __future__ import annotations

import io
import json
import random
from pathlib import Path


def choose_rows(dataset, count: int, strategy: str, seed: int):
    if strategy == "first":
        rows = list(dataset.take(count))
        return rows, len(rows)
    if strategy != "seeded_reservoir":
        raise ValueError(f"Unknown selection strategy: {strategy}")
    rng = random.Random(seed)
    chosen = []
    seen = 0
    for seen, row in enumerate(dataset, 1):
        if len(chosen) < count:
            chosen.append(row)
        else:
            index = rng.randrange(seen)
            if index < count:
                chosen[index] = row
    chosen.sort(key=lambda row: str(row["id"]))
    return chosen, seen


def duration_band(seconds: float) -> str | None:
    """Whisper's single 30-second window; exclude longer clips from this study."""
    if seconds < 10:
        return "short"
    if seconds < 20:
        return "medium"
    if seconds <= 30:
        return "long"
    return None


def choose_rows_by_duration(dataset, targets: dict[str, int], seed: int,
                            excluded_ids: set[str] | None = None):
    """Independent seeded reservoirs give predefined duration strata."""
    import soundfile as sf

    rng = random.Random(seed)
    chosen = {band: [] for band in targets}
    seen = {band: 0 for band in targets}
    scanned = 0
    excluded_ids = excluded_ids or set()
    for scanned, row in enumerate(dataset, 1):
        if str(row["id"]) in excluded_ids:
            continue
        raw = row["audio"]
        if not isinstance(raw, dict) or not raw.get("bytes"):
            raise RuntimeError("Streaming dataset did not supply encoded audio bytes")
        seconds = sf.info(io.BytesIO(raw["bytes"])).duration
        band = duration_band(seconds)
        if band not in targets:
            continue
        seen[band] += 1
        if len(chosen[band]) < targets[band]:
            chosen[band].append(row)
        else:
            index = rng.randrange(seen[band])
            if index < targets[band]:
                chosen[band][index] = row
    for band, target in targets.items():
        if len(chosen[band]) != target:
            raise RuntimeError(f"Duration band {band} has only {seen[band]} rows; requested {target}")
    rows = sorted((row for group in chosen.values() for row in group), key=lambda row: str(row["id"]))
    return rows, scanned, seen


def prepare(config: dict, split_kind: str, root: Path) -> dict:
    from datasets import load_dataset
    from huggingface_hub import HfApi
    import soundfile as sf

    if split_kind not in ("dev", "test", "test_other"):
        raise ValueError(split_kind)
    api = HfApi()
    dataset_revision = api.dataset_info(config["dataset_id"]).sha
    if config.get("dataset_revision") and dataset_revision != config["dataset_revision"]:
        raise RuntimeError("Dataset revision changed since the previous study")
    split = config[f"{split_kind}_split"]
    count = config[f"{split_kind}_count"]
    directory = root / "data" / split_kind
    directory.mkdir(parents=True, exist_ok=True)
    dataset_config = config.get(f"{split_kind}_dataset_config", config["dataset_config"])
    dataset = load_dataset(config["dataset_id"], dataset_config,
                           split=split, streaming=True, revision=dataset_revision)
    dataset = dataset.decode(False)
    clips = []
    strategy = config.get("selection", "first")
    available_by_band = None
    excluded_ids: set[str] = set()
    exclusion_path = config.get("exclude_manifests", {}).get(split_kind)
    exclusion_paths = ([exclusion_path] if isinstance(exclusion_path, str)
                       else exclusion_path or [])
    for previous_path in exclusion_paths:
        previous = json.loads(Path(previous_path).read_text(encoding="utf-8"))
        if (previous["dataset_id"] != config["dataset_id"] or
                previous["dataset_config"] != dataset_config or
                previous["split"] != split):
            raise ValueError(f"Exclusion manifest does not match {split_kind} source")
        excluded_ids.update(clip["id"] for clip in previous["clips"])
    if strategy == "duration_stratified":
        targets = config[f"{split_kind}_duration_targets"]
        if sum(targets.values()) != count:
            raise ValueError(f"{split_kind} duration targets do not sum to {count}")
        rows, scanned, available_by_band = choose_rows_by_duration(
            dataset, targets, config["seed"], excluded_ids)
    else:
        if excluded_ids:
            raise ValueError("Exclusion manifests require duration_stratified selection")
        rows, scanned = choose_rows(dataset, count, strategy, config["seed"])
    for row in rows:
        raw = row["audio"]
        if not isinstance(raw, dict) or not raw.get("bytes"):
            raise RuntimeError("Streaming dataset did not supply encoded audio bytes")
        samples, sampling_rate = sf.read(io.BytesIO(raw["bytes"]), dtype="float32")
        if sampling_rate != 16000 or samples.ndim != 1:
            raise RuntimeError(f"Expected mono 16 kHz audio, got {samples.shape} at {sampling_rate} Hz")
        clip_id = str(row["id"])
        audio_path = directory / f"{clip_id}.flac"
        sf.write(audio_path, samples, sampling_rate)
        clips.append({"id": clip_id, "speaker_id": row.get("speaker_id"),
                      "text": row["text"], "audio": str(audio_path),
                      "seconds": len(samples) / sampling_rate,
                      "duration_band": duration_band(len(samples) / sampling_rate)})
    if len(clips) != count:
        raise RuntimeError(f"Requested {count} clips, received {len(clips)}")
    if excluded_ids.intersection(clip["id"] for clip in clips):
        raise RuntimeError("Fresh sample overlaps an excluded manifest")
    result = {"dataset_id": config["dataset_id"], "dataset_config": dataset_config,
              "dataset_revision": dataset_revision, "split": split, "selection": strategy,
              "rows_scanned": scanned,
              "duration_targets": config.get(f"{split_kind}_duration_targets"),
              "available_by_band": available_by_band,
              "excluded_manifests": exclusion_paths, "excluded_id_count": len(excluded_ids),
              "count": len(clips), "clips": clips}
    (root / f"{split_kind}_manifest.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    return result


def read_manifest(root: Path, split_kind: str) -> dict:
    path = root / f"{split_kind}_manifest.json"
    if not path.exists():
        raise FileNotFoundError(f"Run prepare --split {split_kind} first: {path}")
    return json.loads(path.read_text(encoding="utf-8"))
