"""Command-line entry point for the Whisper precision study."""
from __future__ import annotations

import argparse
import hashlib
import json
import random
from pathlib import Path

from whisper_precision.core import GROUPS, allocate, cost_bits


def write_json(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True), encoding="utf-8")


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def checksum(value: dict) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


def setup(config: dict, root: Path) -> None:
    import torch
    from whisper_precision.experiment import environment
    random.seed(config["seed"])
    torch.manual_seed(config["seed"])
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(config["seed"])
    root.mkdir(parents=True, exist_ok=True)
    path = root / "environment.json"
    if not path.exists() or "nvidia_smi" not in read_json(path):
        write_json(path, environment(config))


def prepare(config: dict, root: Path, split: str) -> None:
    from whisper_precision.data import prepare as download
    if split == "test" and not (root / "selection.json").exists():
        raise RuntimeError("Freeze selection on dev-clean before preparing test-clean")
    result = download(config, split, root)
    print(f"Prepared {result['count']} {split} clips; dataset revision {result['dataset_revision']}")


def baseline(config: dict, root: Path) -> None:
    from whisper_precision.experiment import evaluate_torch_conditions
    result = evaluate_torch_conditions(config, root, [("fp32", set(GROUPS))], "dev")
    write_json(root / "parameter_inventory.json", result["inventory"])
    write_json(root / "dev_baseline.json", result["conditions"]["fp32"])
    print(f"FP32 dev WER: {result['conditions']['fp32']['wer']:.4f}")


def sensitivity(config: dict, root: Path) -> None:
    from whisper_precision.experiment import evaluate_torch_conditions
    conditions = [("fp32", set(GROUPS)), ("uniform_fake_int8", set())]
    conditions += [(f"quantize_only_{g}", set(GROUPS) - {g}) for g in GROUPS]
    conditions += [(f"preserve_only_{g}", {g}) for g in GROUPS]
    result = evaluate_torch_conditions(config, root, conditions, "dev")
    inventory = result["inventory"]
    sizes, fixed = inventory["group_numel"], inventory["fixed_numel"]
    for condition in result["conditions"].values():
        preserved = set(condition["preserved_groups"])
        condition["theoretical_bits"] = cost_bits(sizes, fixed, preserved)
        condition["theoretical_bytes"] = condition["theoretical_bits"] / 8
        condition["weight_storage_realized"] = False
    write_json(root / "parameter_inventory.json", inventory)
    write_json(root / "dev_sensitivity.json", result["conditions"])
    print("Dev sensitivity complete; simulated weights remain FP32 in memory.")


def select(config: dict, root: Path) -> None:
    path = root / "selection.json"
    if path.exists():
        raise FileExistsError("Selection is frozen. Use a new output_dir for a new study.")
    sensitivity = read_json(root / "dev_sensitivity.json")
    inventory = read_json(root / "parameter_inventory.json")
    manifest = read_json(root / "dev_manifest.json")
    sizes, fixed = inventory["group_numel"], inventory["fixed_numel"]
    fp32_bits = cost_bits(sizes, fixed, set(GROUPS))
    budget = int(fp32_bits * config["budget_fraction_of_fp32"])
    benefits = {g: sensitivity["uniform_fake_int8"]["wer"] -
                sensitivity[f"preserve_only_{g}"]["wer"] for g in GROUPS}
    methods = {method: allocate(sizes, fixed, benefits, budget, method, config["seed"])
               for method in ("greedy", "largest", "random")}
    selection = {"status": "frozen_before_test", "budget_bits": budget,
                 "fp32_theoretical_bits": fp32_bits, "int8_floor_bits": cost_bits(sizes, fixed, set()),
                 "benefit_definition": "uniform_fake_int8_wer minus preserve_only_group_wer on dev",
                 "method": "benefit per extra 24 bits per weight, positive benefits only; one pass",
                 "methods": methods, "benefits": benefits,
                 "method_cost_bits": {m: cost_bits(sizes, fixed, set(groups)) for m, groups in methods.items()},
                 "config_sha256": checksum(config), "dev_manifest_sha256": checksum(manifest),
                 "sensitivity_sha256": checksum(sensitivity)}
    write_json(path, selection)
    print(f"Frozen selection at {budget / 8 / 1e6:.2f} theoretical MB; {methods}")


def final(config: dict, root: Path) -> None:
    from whisper_precision.data import read_manifest
    from whisper_precision.experiment import evaluate_torch_conditions, evaluate_openvino
    selection = read_json(root / "selection.json")
    if selection["config_sha256"] != checksum(config):
        raise RuntimeError("Config changed after selection freeze")
    if selection["dev_manifest_sha256"] != checksum(read_manifest(root, "dev")):
        raise RuntimeError("Dev manifest changed after selection freeze")
    if selection["sensitivity_sha256"] != checksum(read_json(root / "dev_sensitivity.json")):
        raise RuntimeError("Sensitivity data changed after selection freeze")
    conditions = [("fp32", set(GROUPS)), ("uniform_fake_int8", set())]
    conditions += [(method, set(groups)) for method, groups in selection["methods"].items()]
    result = evaluate_torch_conditions(config, root, conditions, "test")
    inventory = result["inventory"]
    for condition in result["conditions"].values():
        condition["theoretical_bits"] = cost_bits(inventory["group_numel"],
                                                  inventory["fixed_numel"],
                                                  set(condition["preserved_groups"]))
        condition["weight_storage_realized"] = False
    write_json(root / "test_simulation.json", result["conditions"])
    ov = {}
    for name, quantized in (("ov_fp32", False), ("ov_int8", True)):
        ov[name] = evaluate_openvino(config, root, "test", quantized)
        write_json(root / "test_openvino.json", ov)
    print("Final test evaluation complete. Generate plots and report next.")


def plot(config: dict, root: Path) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    conditions = read_json(root / "test_simulation.json")
    ov = read_json(root / "test_openvino.json")
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.5), sharey=True)
    simulated = {}
    for name, value in conditions.items():
        point = (round(value["theoretical_bits"] / 8e6, 4), round(100 * value["wer"], 4))
        simulated.setdefault(point, []).append(name)
    for (size, wer), names in simulated.items():
        axes[0].scatter(size, wer, s=70, label=" / ".join(names))
    for name, value in ov.items():
        size, wer = value["serialized_bytes"] / 1e6, 100 * value["wer"]
        axes[1].scatter(size, wer, marker="x", s=90, label=name)
    axes[0].set(xlabel="Theoretical weight MB", ylabel="WER, %", title="PyTorch accuracy simulation")
    axes[1].set(xlabel="Serialized IR MB", title="OpenVINO CPU models")
    upper = max(5, 1.3 * max(100 * v["wer"] for v in [*conditions.values(), *ov.values()]))
    for ax in axes:
        ax.set_ylim(0, upper)
        ax.grid(alpha=0.25)
        ax.legend(loc="upper center", fontsize=8)
    fig.suptitle("Whisper Base on LibriSpeech test-clean")
    fig.tight_layout()
    fig.savefig(root / "wer_vs_storage.png", dpi=180)
    plt.close(fig)
    dev = read_json(root / "dev_sensitivity.json")
    groups = list(GROUPS)
    changes = [100 * (dev[f"quantize_only_{g}"]["wer"] - dev["fp32"]["wer"]) for g in groups]
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.barh(groups, changes)
    ax.scatter(changes, groups, color="black", s=10)
    ax.axvline(0, color="black", linewidth=0.8)
    ax.set(xlabel="Change in dev WER, percentage points", title="Single-group INT8 simulation sensitivity")
    fig.tight_layout()
    fig.savefig(root / "component_sensitivity.png", dpi=180)
    plt.close(fig)
    print(f"Wrote plots to {root}")


def report(config: dict, root: Path) -> None:
    dev = read_json(root / "dev_sensitivity.json")
    test = read_json(root / "test_simulation.json")
    ov = read_json(root / "test_openvino.json")
    selection = read_json(root / "selection.json")
    inventory = read_json(root / "parameter_inventory.json")
    env = read_json(root / "environment.json")
    dev_manifest = read_json(root / "dev_manifest.json")
    test_manifest = read_json(root / "test_manifest.json")
    lines = ["# Research report: layer-wise precision allocation for Whisper Base", "",
             "## Method", "", f"Model: `{env['model_id']}` at `{env['model_revision']}`.",
             f"LibriSpeech: `{dev_manifest['dataset_id']}` at `{dev_manifest['dataset_revision']}`; "
             f"dev-clean `{dev_manifest['count']}` clips, test-clean `{test_manifest['count']}` clips.",
             f"Selection: `{dev_manifest['selection']}` on dev ({dev_manifest['rows_scanned']} rows scanned, "
             f"{len({clip['speaker_id'] for clip in dev_manifest['clips']})} speakers); "
             f"test ({test_manifest['rows_scanned']} rows scanned, "
             f"{len({clip['speaker_id'] for clip in test_manifest['clips']})} speakers).",
             f"Seed `{config['seed']}`. Decode: English transcription, greedy beam=1, "
             f"temperature=0, max_new_tokens={config['max_new_tokens']}; uppercase Unicode alphanumeric normalization.",
             "WER is corpus total word edits divided by total reference words.",
             "The component experiment uses per-output-row symmetric INT8 fake quantization followed by FP32 dequantization.",
             "Its costs are theoretical weight bits; it does not compress stored weights or execute INT8 kernels.",
             "The separate OpenVINO models are exported and serialized; their sizes are actual IR directory bytes.",
             "", "## Final results on test-clean", "",
             "| Configuration | WER | Cost MB | Cost type | Median clip latency s | Clip WER range |", "|---|---:|---:|---|---:|---:|"]
    for name, value in test.items():
        observed = [x for x in value["clip_wer"] if x is not None]
        lines.append(f"| {name} | {value['wer']:.3f} | {value['theoretical_bits']/8e6:.2f} | theoretical | {value['latency_median_s']:.3f} | {min(observed):.3f}–{max(observed):.3f} |")
    for name, value in ov.items():
        observed = [x for x in value["clip_wer"] if x is not None]
        lines.append(f"| {name} | {value['wer']:.3f} | {value['serialized_bytes']/1e6:.2f} | serialized IR | {value['latency_median_s']:.3f} | {min(observed):.3f}–{max(observed):.3f} |")
    lines += ["", "OpenVINO and PyTorch latencies are separate backend measurements; a mixed simulation has no deployment speed claim.",
              "Each clip was timed repeatedly; individual timings and predictions are in the JSON results.",
              "", "## Component sensitivity on dev-clean", "",
              "| Group | Parameters | Quantize only ΔWER pp | Preserve only ΔWER pp vs uniform INT8 |",
              "|---|---:|---:|---:|"]
    for group in GROUPS:
        lines.append(f"| {group} | {inventory['group_numel'][group]:,} | "
                     f"{100*(dev[f'quantize_only_{group}']['wer']-dev['fp32']['wer']):+.3f} | "
                     f"{100*(dev[f'preserve_only_{group}']['wer']-dev['uniform_fake_int8']['wer']):+.3f} |")
    lines += ["", "## Frozen allocation", "",
              f"Budget: {selection['budget_bits']/8e6:.2f} theoretical MB "
              f"({config['budget_fraction_of_fp32']:.0%} of FP32 parameter bits).",
              "Greedy selects positive dev WER benefit per extra 24 bits per weight. Largest and seeded random are controls."]
    for method, groups in selection["methods"].items():
        lines.append(f"- {method}: {', '.join(groups) if groups else 'none'}")
    if len({round(value["wer"], 12) for value in test.values()}) == 1:
        lines += ["", "All simulated test configurations have the same observed WER in this run. "
                  "This subset cannot establish an accuracy advantage for allocation."]
    baseline_hypotheses = [x["hypothesis"] for x in test["fp32"]["predictions"]]
    changed = {name: sum(p["hypothesis"] != reference for p, reference in zip(value["predictions"], baseline_hypotheses))
               for name, value in test.items() if name != "fp32"}
    lines += ["Compared with FP32, changed hypothesis counts by simulated variant: " +
              ", ".join(f"{name} {count}" for name, count in changed.items()) + "."]
    lines += ["", "## Interpretation and threats to validity", "",
              "Clips can share speakers or chapters. Small subsets produce coarse, high-variance WER; "
              "do not generalize this run's ordering.",
              "The budget is an upper bound: uniform INT8 may use much less than the cap, so these configurations "
              "do not all have exactly equal cost. The WER-versus-cost plot shows their actual positions.",
              "Single-group sensitivity need not predict combinations because quantization errors interact.",
              "PyTorch simulated INT8 and OpenVINO weight compression have different schemes and execution; "
              "their WER should not be treated as a controlled precision-only comparison.",
              "OpenVINO IR size includes metadata and scales, while theoretical bits omit them.",
              "Timing medians include first-run calls, vary with backend and host load, and are not a stable throughput benchmark.",
              "This experiment does not establish NPU performance. NPU deployment requires a supported device, "
              "the same exported graph, verified compiled precision, and on-device latency/power measurements.",
              "", "## Figures", "", "![WER versus storage](wer_vs_storage.png)",
              "![Component sensitivity](component_sensitivity.png)", ""]
    (root / "REPORT.md").write_text("\n".join(lines), encoding="utf-8")
    print(f"Wrote {root / 'REPORT.md'}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/smoke.json")
    sub = parser.add_subparsers(dest="command", required=True)
    prep = sub.add_parser("prepare")
    prep.add_argument("--split", choices=("dev", "test"), required=True)
    for name in ("baseline", "sensitivity", "select", "final", "plot", "report"):
        sub.add_parser(name)
    args = parser.parse_args()
    config = read_json(Path(args.config))
    root = Path(config["output_dir"])
    if args.command in ("prepare", "baseline", "sensitivity", "final"):
        setup(config, root)
    {"prepare": lambda: prepare(config, root, args.split),
     "baseline": lambda: baseline(config, root),
     "sensitivity": lambda: sensitivity(config, root),
     "select": lambda: select(config, root),
     "final": lambda: final(config, root),
     "plot": lambda: plot(config, root),
     "report": lambda: report(config, root)}[args.command]()


if __name__ == "__main__":
    main()
